Help find similarity between pdfs
